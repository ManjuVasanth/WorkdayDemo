"""
core_connector.py - Core Connector: Worker (CCW) simulation.

Mirrors the real tenant flow:
  Create Integration System (template: Core Connector: Worker)
    -> Configure Integration Services      (enable/disable section services)
    -> Configure Integration Attributes    (Version, Output Format, filename,
                                            Include Inactive Workers)
    -> Configure Integration Field Attributes (Include in Output per field)
    -> Launch Integration                  (Full File OR Changes Only)

Changes Only works like real CCW change detection: each run snapshots the
output rows; the next "Changes Only" run emits only new/changed workers.
"""

import hashlib
import json
import os
import re
from datetime import datetime

from flask import request, Response, redirect

import mock_workday_server as mws
from mock_workday_server import app
from workday_ui import layout, html_resp, persist, TENANT

SYS_FILE = "integration_systems.json"
OUT_DIR = "cc_output"

TEMPLATE = "Core Connector: Worker"
TPL_CCW = "Core Connector: Worker"
TPL_CCB = "Cloud Connect: Benefits"
TPL_DT = "Document Transformation"
TEMPLATES = [TPL_CCW, TPL_CCB, TPL_DT]

CCB_SERVICES = [
    "Benefits Connector ESB Service*",
    "Cloud Connect: Subscriber Data Section Fields",
    "Cloud Connect: Enrollment Data Section Fields",
    "Core Connector: Integration Maps - Benefits",
]
CCB_SECTIONS = {
    "Cloud Connect: Subscriber Data Section Fields":
        ["First_Name", "Last_Name"],
    "Cloud Connect: Enrollment Data Section Fields":
        ["Plan", "Coverage", "Employee_Cost"],
}
DEFAULT_DT_XSLT = open("dt_generic_csv.xsl").read() \
    if os.path.exists("dt_generic_csv.xsl") else ""


def tpl_of(sys):
    return sys.get("template", TPL_CCW)


def sections_for(sys):
    return CCB_SECTIONS if tpl_of(sys) == TPL_CCB else SECTIONS


SERVICES = [
    "Core Connector: Worker ESB Service*",
    "Core Connector: Date Launch Parameters",
    "Core Connector: Integration Maps - Worker",
    "Core Connector: Worker Integration Configuration",
    "Worker Personal Data Section Fields",
    "Worker Status Data Section Fields",
    "Worker Position Data Section Fields",
    "Worker Compensation Data Section Fields",
]

# Section service -> fields it can emit (Employee_ID is always the reference)
SECTIONS = {
    "Worker Personal Data Section Fields": ["First_Name", "Last_Name", "Email"],
    "Worker Status Data Section Fields": ["Active", "Hire_Date"],
    "Worker Position Data Section Fields": ["Org"],
    "Worker Compensation Data Section Fields": ["Bonus_Count", "Bonus_Total"],
}

DEFAULT_ATTRS = {"Version": "40.0", "Output_Filename": "",
                 "Output_Format": "XML", "Include_Inactive_Workers": False}

SNAPSHOTS = {}        # system_name -> {Employee_ID: row_hash}  (change detection)
CC_EVENTS = []        # process monitor


def load_systems():
    if os.path.exists(SYS_FILE):
        with open(SYS_FILE) as f:
            return {s["system_name"]: s for s in json.load(f)}
    return {}


SYSTEMS = load_systems()


def save_systems():
    persist(SYS_FILE, list(SYSTEMS.values()))


def field_value(worker, field):
    if field == "Bonus_Count":
        return str(len(worker.get("Payments", [])))
    if field == "Bonus_Total":
        return str(sum(float(p["Amount"]) for p in worker.get("Payments", [])))
    return str(worker.get(field, ""))


# ---------------------------------------------------------------------------
# Create Integration System
# ---------------------------------------------------------------------------
@app.route("/task/create-integration-system", methods=["GET", "POST"])
def create_integration_system():
    msg = ""
    if request.method == "POST":
        name = request.form.get("system_name", "").strip()
        if not name:
            msg = '<div class="err-banner">Validation error occurred. System Name is required.</div>'
        elif name in SYSTEMS:
            msg = f'<div class="err-banner">Validation error occurred. Integration System \'{name}\' already exists.</div>'
        else:
            tpl = request.form.get("template", TPL_CCW)
            if tpl == TPL_DT:
                SYSTEMS[name] = {"system_name": name, "template": TPL_DT,
                                 "dt": {"source_system": "",
                                        "xslt": DEFAULT_DT_XSLT,
                                        "output_filename": ""}}
            else:
                svcs = CCB_SERVICES if tpl == TPL_CCB else SERVICES
                secs = CCB_SECTIONS if tpl == TPL_CCB else SECTIONS
                SYSTEMS[name] = {
                    "system_name": name,
                    "template": tpl,
                    "services": {s: True for s in svcs},
                    "attributes": dict(DEFAULT_ATTRS),
                    "fields": {sec: {f: True for f in flds}
                               for sec, flds in secs.items()},
                    "maps": {},
                }
            save_systems()
            return redirect(f"/task/view-integration-system?name={name}")

    body = f"""{msg}
<form method="post"><div class="card">
  <label>System Name <span class="req">*</span></label>
  <input type="text" name="system_name" placeholder="INT001 CCW Outbound">
  <label>New using Template <span class="req">*</span></label>
  <select name="template">{''.join(f'<option>{t}</option>' for t in TEMPLATES)}</select>
  <p style="font-size:12px;color:#888;margin-top:8px">The template pre-loads
  the integration services, attributes, and field sections you then configure.</p>
  <div class="btnrow">
    <button class="btn btn-ok" type="submit">OK</button>
    <a class="btn btn-cancel" href="/home">Cancel</a>
  </div>
</div></form>"""
    return html_resp(layout("Create Integration System",
                            "Template-based integration (no Studio required)",
                            body))


# ---------------------------------------------------------------------------
# View Integration System (hub page, like the related-actions menu)
# ---------------------------------------------------------------------------
@app.route("/task/view-integration-system")
def view_integration_system():
    name = request.args.get("name")
    if not name:
        rows = "".join(
            f'<tr><td><a href="/task/view-integration-system?name={s}">{s}</a></td>'
            f'<td>{d["template"]}</td></tr>' for s, d in SYSTEMS.items()) or \
            '<tr><td colspan="2">No integration systems yet. ' \
            '<a href="/task/create-integration-system">Create one</a>.</td></tr>'
        body = f"""<div class="card"><h2>Integration Systems</h2>
<table><tr><th>System Name</th><th>Template</th></tr>{rows}</table></div>"""
        return html_resp(layout("View Integration System", "All systems", body))

    sys = SYSTEMS.get(name)
    if not sys:
        return html_resp(layout("View Integration System", "",
                                '<div class="err-banner">System not found.</div>'))
    if tpl_of(sys) == TPL_DT:
        dt = sys["dt"]
        body = f"""
<div class="card"><h2>Actions</h2>
  <a class="btn btn-ok" href="/task/configure-document-transformation?sys={name}">Configure Document Transformation</a>
  <a class="btn btn-ok" href="/task/launch-integration?sys={name}" style="margin-left:8px">Launch Integration</a>
</div>
<div class="card"><h2>Document Transformation</h2>
<table><tr><th>Setting</th><th>Value</th></tr>
<tr><td>Source Integration System</td><td>{dt.get('source_system') or '(not set)'}</td></tr>
<tr><td>Output Filename</td><td>{dt.get('output_filename') or '(sequence generator)'}</td></tr>
<tr><td>XSLT</td><td>{len(dt.get('xslt',''))} bytes attached</td></tr></table>
<p style="font-size:12px;color:#888;margin-top:8px">A DT system has no data
services of its own: it consumes the XML output of its source connector and
applies the attached XSLT - the standard Core Connector -> DT chain.</p></div>"""
        return html_resp(layout("View Integration System",
                                f"{name} - Template: {TPL_DT}", body))
    svc_rows = "".join(
        f'<tr><td>{tpl_of(sys)} / {s}</td>'
        f'<td>{"Yes" if on else "No"}</td></tr>'
        for s, on in sys["services"].items())
    attrs = "".join(f"<tr><td>{k.replace('_', ' ')}</td><td>{v}</td></tr>"
                    for k, v in sys["attributes"].items())
    body = f"""
<div class="card"><h2>Actions (related actions menu)</h2>
  <a class="btn btn-ok" href="/task/configure-integration-services?sys={name}">Configure Integration Services</a>
  <a class="btn btn-ok" href="/task/configure-integration-attributes?sys={name}" style="margin-left:8px">Configure Integration Attributes</a>
  <a class="btn btn-ok" href="/task/configure-field-attributes?sys={name}" style="margin-left:8px">Configure Integration Field Attributes</a>
  <a class="btn btn-ok" href="/task/configure-integration-maps?sys={name}" style="margin-left:8px">Configure Integration Maps</a>
  <a class="btn btn-ok" href="/task/launch-integration?sys={name}" style="margin-left:8px">Launch Integration</a>
</div>
<div class="card"><h2>Integration Services</h2>
<table><tr><th>Integration Template Service</th><th>Enabled</th></tr>{svc_rows}</table></div>
<div class="card"><h2>Integration Attributes</h2>
<table><tr><th>Attribute</th><th>Value</th></tr>{attrs}</table></div>"""
    return html_resp(layout(f"View Integration System",
                            f"{name} - Template: {tpl_of(sys)}", body))


# ---------------------------------------------------------------------------
# Configure Integration Services
# ---------------------------------------------------------------------------
@app.route("/task/configure-integration-services", methods=["GET", "POST"])
def configure_services():
    name = request.values.get("sys")
    sys = SYSTEMS.get(name)
    if not sys:
        return redirect("/task/view-integration-system")
    if tpl_of(sys) == TPL_DT:
        return redirect(f"/task/configure-document-transformation?sys={name}")
    msg = ""
    if request.method == "POST":
        on = set(request.form.getlist("svc"))
        for s in sys["services"]:
            if s.endswith("*"):
                sys["services"][s] = True        # initial service is mandatory
            else:
                sys["services"][s] = s in on
        save_systems()
        msg = '<div class="ok-banner">Integration services updated.</div>'

    checks = "".join(
        f'<tr><td>{tpl_of(sys)} / {s}</td>'
        f'<td><input type="checkbox" name="svc" value="{s}" '
        f'{"checked" if on else ""} {"disabled" if s.endswith("*") else ""}></td>'
        f'<td>{"Initial Service to Invoke" if s.endswith("*") else ""}</td></tr>'
        for s, on in sys["services"].items())
    body = f"""{msg}
<form method="post"><input type="hidden" name="sys" value="{name}">
<div class="card"><h2>Integration Template: {tpl_of(sys)}</h2>
<table><tr><th>Integration Template Service</th><th>Enabled</th><th></th></tr>
{checks}</table>
<p style="font-size:12px;color:#888;margin-top:10px">Disabling a Section
Fields service removes that whole section from the output, regardless of the
field attribute configuration.</p>
<div class="btnrow"><button class="btn btn-ok">OK</button>
<a class="btn btn-cancel" href="/task/view-integration-system?name={name}">Cancel</a></div>
</div></form>"""
    return html_resp(layout("Configure Integration Services", name, body))


# ---------------------------------------------------------------------------
# Configure Integration Attributes
# ---------------------------------------------------------------------------
@app.route("/task/configure-integration-attributes", methods=["GET", "POST"])
def configure_attributes():
    name = request.values.get("sys")
    sys = SYSTEMS.get(name)
    if not sys:
        return redirect("/task/view-integration-system")
    if tpl_of(sys) == TPL_DT:
        return redirect(f"/task/configure-document-transformation?sys={name}")
    msg = ""
    if request.method == "POST":
        a = sys["attributes"]
        a["Version"] = request.form.get("version", "40.0")
        a["Output_Filename"] = request.form.get("filename", "").strip()
        a["Output_Format"] = request.form.get("format", "XML")
        a["Include_Inactive_Workers"] = request.form.get("inactive") == "on"
        save_systems()
        msg = '<div class="ok-banner">Integration attributes updated.</div>'

    a = sys["attributes"]
    body = f"""{msg}
<form method="post"><input type="hidden" name="sys" value="{name}">
<div class="card"><h2>Integration Template: {tpl_of(sys)}</h2>
  <label>Version <span style="font-weight:400;color:#888">(Required for Launch -
    controls the version of the output file)</span></label>
  <select name="version">
    <option {"selected" if a["Version"] == "40.0" else ""}>40.0</option>
    <option {"selected" if a["Version"] == "39.0" else ""}>39.0</option>
    <option {"selected" if a["Version"] == "38.0" else ""}>38.0</option>
  </select>
  <label>Output Filename <span style="font-weight:400;color:#888">(leave empty
    to use the filename sequence generator)</span></label>
  <input type="text" name="filename" value="{a['Output_Filename']}"
         placeholder="ccw_workers.xml">
  <label>Output Format</label>
  <select name="format">
    <option {"selected" if a["Output_Format"] == "XML" else ""}>XML</option>
    <option {"selected" if a["Output_Format"] == "CSV" else ""}>CSV</option>
  </select>
  <label><input type="checkbox" name="inactive"
    {"checked" if a["Include_Inactive_Workers"] else ""}>
    Include Inactive Workers in Full File</label>
  <div class="btnrow"><button class="btn btn-ok">OK</button>
  <a class="btn btn-cancel" href="/task/view-integration-system?name={name}">Cancel</a></div>
</div></form>"""
    return html_resp(layout("Configure Integration Attributes", name, body))


# ---------------------------------------------------------------------------
# Configure Integration Field Attributes
# ---------------------------------------------------------------------------
@app.route("/task/configure-field-attributes", methods=["GET", "POST"])
def configure_field_attributes():
    name = request.values.get("sys")
    sys = SYSTEMS.get(name)
    if not sys:
        return redirect("/task/view-integration-system")
    if tpl_of(sys) == TPL_DT:
        return redirect(f"/task/configure-document-transformation?sys={name}")
    msg = ""
    if request.method == "POST":
        on = set(request.form.getlist("field"))
        for sec, flds in sys["fields"].items():
            for f in flds:
                flds[f] = f"{sec}|{f}" in on
        save_systems()
        msg = '<div class="ok-banner">Field attributes updated.</div>'

    sections = ""
    for sec, flds in sys["fields"].items():
        rows = "".join(
            f'<tr><td>{f.replace("_", " ")}</td>'
            f'<td><input type="checkbox" name="field" value="{sec}|{f}" '
            f'{"checked" if on else ""}></td></tr>'
            for f, on in flds.items())
        sections += f"""<div class="card"><h2>{sec}</h2>
<table><tr><th>Field(s)</th><th>Include in Output</th></tr>{rows}</table></div>"""

    body = f"""{msg}
<form method="post"><input type="hidden" name="sys" value="{name}">
<p style="font-size:13px;color:#666;margin-bottom:14px">Fields with a tick in
the "Include in Output" column will be included in the output file.
Employee ID is always emitted as the Worker Reference.</p>
{sections}
<div class="btnrow"><button class="btn btn-ok">OK</button>
<a class="btn btn-cancel" href="/task/view-integration-system?name={name}">Cancel</a></div>
</form>"""
    return html_resp(layout("Configure Integration Field Attributes", name, body))


# ---------------------------------------------------------------------------
# Launch Integration (Full File / Changes Only)
# ---------------------------------------------------------------------------
def _apply_map(maps, f, v):
    m = maps.get(f)
    if m:
        return m["entries"].get(v, m.get("default", v))
    return v


def build_rows(sys):
    """Apply attributes + services + field config + integration maps."""
    include_inactive = sys["attributes"]["Include_Inactive_Workers"]
    maps = sys.get("maps", {})
    field_maps = sys.get("field_maps", {})   # internal field -> external name
    secs = sections_for(sys)
    rows = []

    if tpl_of(sys) == TPL_CCB:
        # Benefits carrier connector: one record per enrollment
        for w in mws.WORKERS:
            if w["Active"] != "1" and not include_inactive:
                continue
            for b in w.get("Benefits", []):
                row = {"Employee_ID": w["Employee_ID"],
                       "_key": f"{w['Employee_ID']}|{b['Plan']}",
                       "_sections": {}}
                for sec, flds in secs.items():
                    if not sys["services"].get(sec):
                        continue
                    picked = {}
                    for f in flds:
                        if not sys["fields"][sec].get(f):
                            continue
                        raw = (str(b.get(f, "")) if f in b
                               else field_value(w, f))
                        out = field_maps.get(f, f)         # external field name
                        picked[out] = _apply_map(maps, f, raw)
                    if picked:
                        row["_sections"][sec] = picked
                rows.append(row)
        return rows

    for w in mws.WORKERS:
        if w["Active"] != "1" and not include_inactive:
            continue
        row = {"Employee_ID": w["Employee_ID"],
               "_key": w["Employee_ID"], "_sections": {}}
        for sec, flds in secs.items():
            if not sys["services"].get(sec):
                continue
            picked = {}
            for f in flds:
                if not sys["fields"][sec].get(f):
                    continue
                out = field_maps.get(f, f)                 # external field name
                picked[out] = _apply_map(maps, f, field_value(w, f))
            if picked:
                row["_sections"][sec] = picked
        rows.append(row)
    return rows


# ---------------------------------------------------------------------------
# Configure Integration Maps (internal Workday field -> external field name)
# ---------------------------------------------------------------------------
@app.route("/task/configure-integration-maps", methods=["GET", "POST"])
def configure_integration_maps():
    name = request.values.get("sys") or next(iter(SYSTEMS), None)
    sys = SYSTEMS.get(name)
    if not sys:
        return redirect("/task/create-integration-system")
    sys.setdefault("maps", {})
    sys.setdefault("field_maps", {})
    msg = ""

    secs = sections_for(sys)
    # only fields actually enabled on an enabled service are worth mapping
    enabled_fields = []
    for sec, flds in secs.items():
        if not sys["services"].get(sec):
            continue
        for f in flds:
            if sys["fields"].get(sec, {}).get(f) and f not in enabled_fields:
                enabled_fields.append(f)
    if not enabled_fields:
        enabled_fields = [f for flds in secs.values() for f in flds]

    if request.method == "POST" and request.form.get("save") == "1":
        fm = {}
        for f in enabled_fields:
            ext = request.form.get("ext|" + f, "").strip()
            if ext and ext != f:
                fm[f] = ext
        sys["field_maps"] = fm
        save_systems()
        msg = (f'<div class="ok-banner">Field mapping saved: '
               f'<b>{len(fm)}</b> field(s) renamed. Launch the integration to '
               f'see the external field names in the output XML/CSV.</div>')

    fm = sys.get("field_maps", {})
    rows = "".join(
        f'<tr><td><b>{f}</b></td>'
        f'<td><span class="arrow">&#8594;</span></td>'
        f'<td><input type="text" name="ext|{f}" value="{fm.get(f, "")}" '
        f'placeholder="{f}" style="max-width:240px"></td></tr>'
        for f in enabled_fields)
    body = f"""{msg}
<form method="post">
  <input type="hidden" name="sys" value="{name}">
  <input type="hidden" name="save" value="1">
<div class="card"><h2>Integration Maps - {name}</h2>
  <p style="font-size:13px;color:#666;margin-bottom:12px">Map each
  <b>internal Workday field</b> to the <b>external field name</b> the partner
  expects (the XML tag / CSV header). This maps the <b>field</b>, not each value
  - e.g. <code>First_Name &rarr; First</code>. Leave blank to keep the internal
  name.</p>
  <table class="grid">
    <tr><th style="width:34%">Internal Field (Workday)</th><th style="width:6%"></th>
        <th>External Field Name</th></tr>
    {rows}
  </table>
  <div class="btnrow"><button class="btn btn-ok">OK</button>
  <a class="btn btn-cancel" href="/task/view-integration-system?name={name}">Cancel</a></div>
</div></form>
<style>.arrow{{color:#2E6DA4;font-weight:700;font-size:16px}}</style>"""
    return html_resp(layout("Configure Integration Maps", name, body))


def row_hash(row):
    return hashlib.md5(json.dumps(row, sort_keys=True).encode()).hexdigest()


def to_xml(rows, version, record_tag="Worker", root_tag="Workers"):
    parts = [f'<?xml version="1.0" encoding="UTF-8"?>',
             f'<wd:{root_tag} xmlns:wd="urn:com.workday/ccw" wd:version="{version}">']
    for r in rows:
        parts.append(f'  <wd:{record_tag}>\n    <wd:Worker_Reference>'
                     f'\n      <wd:ID wd:type="Employee_ID">{r["Employee_ID"]}</wd:ID>'
                     f'\n    </wd:Worker_Reference>')
        for sec, flds in r["_sections"].items():
            tag = re.sub(r"_+", "_",
                         re.sub(r"[^\w]", "_",
                                sec.replace(" Section Fields", ""))).strip("_")
            parts.append(f"    <wd:{tag}>")
            for f, v in flds.items():
                parts.append(f"      <wd:{f}>{v}</wd:{f}>")
            parts.append(f"    </wd:{tag}>")
        parts.append(f"  </wd:{record_tag}>")
    parts.append(f"</wd:{root_tag}>")
    return "\n".join(parts)


def to_csv(rows):
    cols = ["Employee_ID"]
    for sec, flds in SECTIONS.items():
        cols += [f for f in flds]
    seen = []
    for r in rows:
        flat = {"Employee_ID": r["Employee_ID"]}
        for sec in r["_sections"].values():
            flat.update(sec)
        seen.append(flat)
    used = [c for c in cols if any(c in s for s in seen)]
    out = [",".join(used)]
    out += [",".join(s.get(c, "") for c in used) for s in seen]
    return "\n".join(out)


@app.route("/task/launch-integration", methods=["GET", "POST"])
def launch_integration():
    name = request.values.get("sys") or next(iter(SYSTEMS), None)
    sys = SYSTEMS.get(name)
    if not sys:
        return redirect("/task/create-integration-system")

    msg = ""
    if request.method == "POST" and request.form.get("simulate") == "1":
        # Demo helper: mutate one worker so Changes Only has something to find
        w = mws.WORKERS[4]
        orgs = ["Finance", "HR Operations", "IT Services", "Audit", "Legal"]
        w["Org"] = orgs[(orgs.index(w["Org"]) + 1) % len(orgs)]
        msg = (f'<div class="ok-banner">Simulated change: worker '
               f'{w["Employee_ID"]} moved to <b>{w["Org"]}</b>. '
               f'Run Changes Only now.</div>')

    elif request.method == "POST" and tpl_of(sys) == TPL_DT:
        msg = run_document_transformation(sys)

    elif request.method == "POST":
        mode = request.form.get("mode", "full")
        rows = build_rows(sys)
        current = {r["_key"]: row_hash(r) for r in rows}

        if mode == "changes":
            prev = SNAPSHOTS.get(name, {})
            rows = [r for r in rows
                    if prev.get(r["_key"]) != current[r["_key"]]]
        SNAPSHOTS[name] = current

        ccb = tpl_of(sys) == TPL_CCB
        a = sys["attributes"]
        os.makedirs(OUT_DIR, exist_ok=True)
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        ext = "xml" if a["Output_Format"] == "XML" else "csv"
        fname = a["Output_Filename"] or f"{name.replace(' ', '_')}_{stamp}.{ext}"
        content = (to_xml(rows, a["Version"],
                          record_tag="Enrollment_Record" if ccb else "Worker",
                          root_tag="Benefit_Enrollments" if ccb else "Workers")
                   if ext == "xml" else to_csv(rows))
        with open(os.path.join(OUT_DIR, fname), "w") as f:
            f.write(content)

        CC_EVENTS.append({"sys": name, "time": stamp,
                          "mode": "Full File" if mode == "full" else "Changes Only",
                          "rows": len(rows), "file": fname})
        msg = (f'<div class="ok-banner"><b>{name}</b> completed - '
               f'{"Full File" if mode == "full" else "Changes Only"}: '
               f'{len(rows)} worker(s) in output. '
               f'<a href="/cc-output/{fname}" target="_blank">View {fname}</a></div>')

    events = "".join(
        f'<tr><td>{e["time"]}</td><td>{e["sys"]}</td><td>{e["mode"]}</td>'
        f'<td>{e["rows"]}</td>'
        f'<td><a href="/cc-output/{e["file"]}" target="_blank">{e["file"]}</a></td></tr>'
        for e in reversed(CC_EVENTS)) or \
        '<tr><td colspan="5">No runs yet.</td></tr>'

    if tpl_of(sys) == TPL_DT:
        body = f"""{msg}
<form method="post"><input type="hidden" name="sys" value="{name}">
<div class="card"><h2>Launch {name} (Document Transformation)</h2>
<p style="font-size:13px;color:#666">Runs the source connector (Full File),
then applies the attached XSLT to its XML output - the standard
Core Connector -&gt; DT integration process chain.</p>
<div class="btnrow"><button class="btn btn-ok">OK</button></div></div></form>
<div class="card"><h2>Process Monitor</h2>
<table><tr><th>Time</th><th>System</th><th>Mode</th><th>Rows</th><th>Output</th></tr>
{events}</table></div>"""
        return html_resp(layout("Launch Integration",
                                f"{name} - Template: {TPL_DT}", body))

    body = f"""{msg}
<form method="post"><input type="hidden" name="sys" value="{name}">
<div class="card"><h2>Launch {name}</h2>
  <label>Launch Parameters</label>
  <div class="checks">
    <label><input type="radio" name="mode" value="full" checked> Full File</label>
    <label><input type="radio" name="mode" value="changes"> Changes Only
      (since last run)</label>
  </div>
  <div class="btnrow">
    <button class="btn btn-ok">OK</button>
    <button class="btn btn-cancel" name="simulate" value="1">Simulate a data
      change</button>
  </div>
</div></form>
<div class="card"><h2>Process Monitor</h2>
<table><tr><th>Time</th><th>System</th><th>Mode</th><th>Rows</th><th>Output</th></tr>
{events}</table></div>"""
    return html_resp(layout("Launch Integration",
                            f"{name} - Template: {TEMPLATE}", body))


def run_document_transformation(sys):
    dt = sys["dt"]
    src_name = dt.get("source_system")
    source = SYSTEMS.get(src_name)
    if not source or tpl_of(source) == TPL_DT:
        return ('<div class="err-banner">Validation error occurred. Set a '
                'valid (non-DT) Source Integration System in Configure '
                'Document Transformation.</div>')
    # 1. Run the source connector (Full File) - first event in the chain
    rows = build_rows(source)
    SNAPSHOTS[src_name] = {r["_key"]: row_hash(r) for r in rows}
    ccb = tpl_of(source) == TPL_CCB
    a = source["attributes"]
    xml = to_xml(rows, a["Version"],
                 record_tag="Enrollment_Record" if ccb else "Worker",
                 root_tag="Benefit_Enrollments" if ccb else "Workers")
    os.makedirs(OUT_DIR, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    src_file = f"{src_name.replace(' ', '_')}_{stamp}.xml"
    with open(os.path.join(OUT_DIR, src_file), "w") as f:
        f.write(xml)
    CC_EVENTS.append({"sys": src_name, "time": stamp, "mode": "Full File "
                      "(chained)", "rows": len(rows), "file": src_file})
    # 2. Apply the attached XSLT - second event
    try:
        from lxml import etree
        xslt = etree.XSLT(etree.fromstring(dt["xslt"].encode()))
        out = str(xslt(etree.fromstring(xml.encode())))
    except Exception as e:
        return (f'<div class="err-banner">Document Transformation failed: '
                f'{type(e).__name__}: {e}</div>')
    dt_file = dt.get("output_filename") or \
        f"{sys['system_name'].replace(' ', '_')}_{stamp}.txt"
    with open(os.path.join(OUT_DIR, os.path.basename(dt_file)), "w") as f:
        f.write(out)
    CC_EVENTS.append({"sys": sys["system_name"], "time": stamp,
                      "mode": "Document Transformation",
                      "rows": len(rows), "file": os.path.basename(dt_file)})
    return (f'<div class="ok-banner">Chain completed: <b>{src_name}</b> '
            f'({len(rows)} records) -&gt; XSLT -&gt; '
            f'<a href="/cc-output/{os.path.basename(dt_file)}" target="_blank">'
            f'{os.path.basename(dt_file)}</a></div>')


@app.route("/task/configure-document-transformation", methods=["GET", "POST"])
def configure_document_transformation():
    name = request.values.get("sys")
    sys = SYSTEMS.get(name)
    if not sys or tpl_of(sys) != TPL_DT:
        return redirect("/task/view-integration-system")
    msg = ""
    if request.method == "POST":
        sys["dt"]["source_system"] = request.form.get("source_system", "")
        sys["dt"]["xslt"] = request.form.get("xslt", DEFAULT_DT_XSLT)
        sys["dt"]["output_filename"] = request.form.get("output_filename",
                                                        "").strip()
        save_systems()
        msg = '<div class="ok-banner">Document Transformation configured.</div>'
    sources = [s for s, d in SYSTEMS.items() if tpl_of(d) != TPL_DT]
    opts = "".join(f'<option {"selected" if s == sys["dt"].get("source_system") else ""}>{s}</option>'
                   for s in sources)
    body = f"""{msg}
<form method="post"><input type="hidden" name="sys" value="{name}">
<div class="card"><h2>Document Transformation - {name}</h2>
  <label>Source Integration System (connector whose output this transforms)</label>
  <select name="source_system">{opts}</select>
  <label>Attached XSLT</label>
  <textarea name="xslt" rows="14">{sys["dt"].get("xslt","")}</textarea>
  <label>Output Filename (blank = sequence generator)</label>
  <input type="text" name="output_filename"
         value="{sys["dt"].get("output_filename","")}"
         placeholder="carrier_file.csv">
  <div class="btnrow"><button class="btn btn-ok">OK</button>
  <a class="btn btn-cancel" href="/task/view-integration-system?name={name}">Cancel</a></div>
</div></form>"""
    return html_resp(layout("Configure Document Transformation", name, body))


@app.route("/cc-output/<path:fname>")
def cc_output(fname):
    path = os.path.join(OUT_DIR, os.path.basename(fname))
    if not os.path.exists(path):
        return Response("Output not found", status=404)
    mt = "text/xml" if fname.endswith(".xml") else "text/plain"
    with open(path) as f:
        return Response(f.read(), mimetype=mt)
